// Turn pages with the keyboard, like flipping through the issue.
(function(){
  function go(attr){
    var href = document.body.getAttribute(attr);
    if(href) window.location.href = href;
  }
  document.addEventListener('keydown', function(e){
    if(e.metaKey || e.ctrlKey || e.altKey) return;
    var t = e.target;
    if(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    if(e.key === 'ArrowRight') go('data-next');
    if(e.key === 'ArrowLeft') go('data-prev');
  });
  // Close search on Escape.
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
      var r = document.getElementById('search-results');
      if(r) r.classList.remove('open');
    }
  });
})();
