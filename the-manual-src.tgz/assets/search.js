(function(){
  var input, results;
  function init(){
    input = document.getElementById('site-search');
    results = document.getElementById('search-results');
    if(!input || !window.SEARCH_INDEX) return;
    input.addEventListener('input', onInput);
    input.addEventListener('focus', onInput);
    document.addEventListener('click', function(e){
      if(!e.target.closest('.searchbox')) results.classList.remove('open');
    });
  }
  function onInput(){
    var q = input.value.trim().toLowerCase();
    if(q.length < 1){ results.classList.remove('open'); results.innerHTML=''; return; }
    var matches = window.SEARCH_INDEX.filter(function(item){
      return item.title.toLowerCase().indexOf(q) !== -1 ||
             item.tags.toLowerCase().indexOf(q) !== -1 ||
             item.snippet.toLowerCase().indexOf(q) !== -1;
    }).slice(0, 8);
    if(matches.length === 0){
      results.innerHTML = '<div class="sr-empty">No entries match "'+escapeHtml(q)+'".</div>';
    } else {
      results.innerHTML = matches.map(function(m){
        return '<a href="'+m.url+'"><div class="sr-part">'+m.part+'</div><div class="sr-title">'+m.title+'</div><div class="sr-snip">'+m.snippet+'</div></a>';
      }).join('');
    }
    results.classList.add('open');
  }
  function escapeHtml(s){
    return s.replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; });
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }
})();
