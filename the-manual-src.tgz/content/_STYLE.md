# The Manual — writer's brief

The Manual (the-manual.cloud) is an online magazine in the manner of 1960s Esquire: a unisex
encyclopedia of everything an adult is supposed to know between 16 and 36. Every guide has a short
entry (about 40 words, already written for existing guides) and a full article behind a READ MORE
link. You are writing the full articles.

## Voice

- Plain-spoken, confident, specific, a little dry. Service journalism from a magazine that respects
  the reader. Second person ("you"). No hype, no filler, no throat-clearing, no "in today's world".
- Unisex. No gendered assumptions, no "for him" or "for her". (The Gentleman's Guide is the one
  exception: it is written for men, in the same voice.)
- American context (dollars, miles, Fahrenheit, US law and institutions), stated plainly.
- Concrete: real numbers, real intervals, real sequences, named mistakes. "Every five to seven
  thousand miles" beats "regularly".
- Any recommendation for skin or clothes defaults to fragrance-free.
- No brand names, no product endorsements, no apps named by name unless it is unavoidable
  (a government site such as IRS Free File or annualcreditreport.com is fine).
- No celebrities, no pop-culture references, no musicians.
- Every sentence is a complete grammatical sentence, including every bullet and every numbered
  step. Headings are short labels (two to six words) and are the only fragments allowed.
- No emoji. No exclamation marks. No rhetorical questions. No em-dash pile-ups: at most one dash
  construction per paragraph.
- Do not open with a definition and do not close with a summary paragraph that repeats the piece.

## Accuracy

- This is practical general information for a wide audience. Be correct. If you are not sure a
  fact is right, leave it out.
- Laws, limits and thresholds that change every year (tax brackets, IRA and 401(k) contribution
  limits, FSA limits, standard deduction, filing deadlines that move) must not be given as hard
  numbers. Say "the annual limit, which the IRS adjusts most years" and tell the reader where to
  look it up. Long-standing rules of thumb and stable figures are fine.
- Where rules vary by state or country, say so in one sentence and tell the reader how to find
  the local rule.
- Medical, legal and financial topics: give the practical mechanics and the point at which a
  professional is needed. Never give dosing instructions beyond "follow the label". Do not add a
  disclaimer paragraph; the site already carries one.
- Safety-critical steps (jump-starting a car, CPR, gas leaks, food temperatures) must be in the
  correct order and must match mainstream guidance (AAA, Red Cross, USDA, CDC, NHTSA).

## Length and structure

- 330 to 430 words per article, counted over everything below the header lines.
- The existing short entry is shown above the article as its deck. Do not repeat it. Start where
  it leaves off: more depth, the mechanics, the sequence, the mistakes, the money.
- Three to five sections, each opened by a "## " heading.
- Mostly paragraphs. Use one bulleted or numbered list where the content really is a list or a
  sequence. Numbered steps for procedures.
- End with exactly one "!tip:" line or one "!note:" line: a single useful sentence or two that
  is not a repeat of the body.
- The first paragraph begins with a letter (it gets a drop cap), never a digit or a quote mark.
- **Bold** may be used sparingly for a term being defined. No other markup, no links, no HTML.

## File format

Plain text. One file holds many guides. Each guide starts with a line `=== ` followed by the
exact title you were given. Do not change titles.

For an EXISTING guide:

    === Changing a flat tire

    ## Before you lift the car
    Paragraph text on one line or wrapped, it does not matter.

    ## The sequence
    1. A complete sentence.
    2. Another complete sentence.

    !tip: One closing tip.

For a NEW guide, add three header lines directly under the title line, then a blank line:

    === Getting your driver's license
    new: yes
    tags: license, driving, DMV
    short: Two or three plain sentences, 35 to 50 words in total, in the same voice as the existing short entries. It must stand on its own as the entry on the Part page and give the single most useful piece of advice first.

    ## First heading
    ...

Rules for the header lines: `tags:` is two to four lowercase search tags separated by commas;
`short:` is one line with no line breaks.

See `content/_EXAMPLE.txt` for a finished guide in the right voice and at the right length.
