# The Manual — the-manual.cloud

An online magazine in the manner of 1960s Esquire: 500 guides in thirteen parts, plus
The Gentleman's Guide (26 chapters) at /gentleman.

- `build/build.js` builds the whole static site into the repo root (`node build/build.js`). Vercel runs it on deploy.
- `build/data.manual*.js`, `build/data.gentleman.js`: the short entries shown on each Part page.
- `content/*.txt`: the full articles behind every READ MORE link, and the 270 newer guides.
  The format and the writer's brief are in `content/_STYLE.md`; `node build/check-content.js <file>` validates a file.
- `build/art.js`: Midjourney job ids for every illustration; the build downloads them into `assets/art/`.
- Fonts: `assets/fonts/Esquivel.woff2` (display). Eurostile Medium is the text face.
